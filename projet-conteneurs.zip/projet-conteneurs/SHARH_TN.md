# شرح المشروع بالتونسي: Docker و Kubernetes

> هالملف يشرحلك المشروع من الصفر، كيما كان تحكي مع صاحبك. المصطلحات التقنية خليتها بالفرنسي/الإنجليزي كيما تلقاها في الكورس والـdémo.

---

## 1. شنوا يطلب منك الأستاذ بالضبط؟

الأستاذ يحب يشوف إنك تعرف تعدّي من **الـVM (الماكينة الافتراضية)** لـ**الـconteneurs**، وتعمل 3 حاجات:

1. تاخذ تطبيق متكوّن من 3 قطع (واجهة، API، قاعدة بيانات) وتحط كل قطعة في **conteneur** (Docker).
2. تخدّم القطع الكل مع بعضها في الجهاز متاعك بملف واحد (**Docker Compose**).
3. تعدّيهم لـ**orchestrateur** (Kubernetes) وتورّيه كيفاش تكبّر وتصغّر عدد النسخ (**scalabilité**).

وهذا كل. المشروع الجاهز عندك يعمل الـ3 حاجات.

---

## 2. الـVM والـconteneur: الفرق بمثال

- **الـVM** كيما كانك تكري **دار كاملة** باش تقعد فيها: فيها كل شي (جدران، كهرباء، ماء) وتتقل ووقت الدخول يطول.
- **الـconteneur** كيما كانك تكري **غرفة** في دار كبيرة: تتقاسم الكهرباء والماء (نفس الـnoyau متاع النظام) مع الغرف الأخرى. خفيف، يبدا في ثواني، وتنجم تركّب بيه برشا غرف في نفس الماكينة.

الميزة الكبيرة: التطبيق يخدم **بنفس الشكل** في كل بلاصة. ما عادش تقول "عندي يخدم، عندك لا".

---

## 3. المصطلحات الأساسية (الجدول اللي لازمك تحفظو)

| المصطلح | بالتونسي |
|---|---|
| **Image** | الوصفة/القالب: ملف جاهز فيه التطبيق وكل ما يحتاجو، ما يتبدلش |
| **Conteneur** | الصحن اللي طيّبتو بالوصفة: نسخة تخدم من الـimage |
| **Dockerfile** | ورقة التعليمات اللي تقول لـDocker كيفاش يبني الـimage |
| **Multi-stage** | نبني في مرحلة أولى (فيها أدوات ثقيلة) ونحط في الـimage النهائية كان النتيجة. النتيجة: image خفيفة |
| **.dockerignore** | قائمة الملفات اللي ما نحبش تدخل في الـimage |
| **Docker Compose** | ملف واحد `docker-compose.yml` يشغّل كل الـconteneurs مع بعضهم |
| **Volume** | "فلاشة" برّا الـconteneur: كي تمسح الـconteneur، المعلومات تبقى |
| **Réseau (network)** | الشبكة اللي تخلّي الـconteneurs تحكي مع بعضها بالاسم (مثلا `redis`) |
| **Kubernetes (K8s)** | المسؤول اللي يدير الـconteneurs: يشغّلهم، يبدّل اللي مات، يكبّر عددهم |
| **Minikube** | Kubernetes صغير يخدم في الكمبيوتر متاعك للتجربة |
| **Pod** | أصغر وحدة في K8s: فيه conteneur (أو أكثر) |
| **Deployment** | يقول لـK8s: "نحب 3 نسخ من هالـPod ديما خدامين" وإذا واحد مات يعوّضو |
| **Service** | عنوان ثابت لمجموعة Pods، ويوزّع الطلبات بينهم (load balancing) |
| **StatefulSet** | كيما Deployment لكن للقواعد (فيها بيانات): الـPod يحافظ على اسمو وعلى التخزين متاعو |
| **PVC** | طلب مساحة تخزين دايمة للـPod |
| **ConfigMap / Secret** | الإعدادات / الأسرار (كلمة السر) باش ما نكتبوهمش في الكود |
| **Probes (liveness/readiness)** | فحوصات: "هل الـPod حي؟" و"هل جاهز يستقبل الطلبات؟" |
| **HPA** | يكبّر ويصغّر عدد الـPods وحدو حسب الضغط على الـCPU |
| **NetworkPolicy** | قوانين الشبكة: شكون يحكي مع شكون |

---

## 4. التطبيق اللي عملناه: 3 قطع

```
المتصفح  →  frontend (Nginx)  →  backend (Node.js)  →  redis (قاعدة البيانات)
```

- **frontend**: الصفحة اللي تشوفها (عدّاد زيارات، دفتر ذهبي، زر "interroger l'API ×10").
- **backend**: الـAPI اللي تحسب الزيارات وتخزّن الرسائل.
- **redis**: القاعدة اللي تخزّن. عندها Dockerfile متاعنا (فيها `redis.conf`) وكلمة سر.

**شنوا يعمل زر "×10"؟** يبعث 10 طلبات للـAPI ويورّيك اسم الـPod اللي جاوب كل مرة. كي تكبّر عدد النسخ لـ5 تشوف 5 أسماء مختلفة: هذا هو الـ**load balancing** وهذا اللي تورّيه للأستاذ.

---

## 5. الملفات اللي في المشروع وشنوا يعمل كل واحد

| الملف | الدور | النقطة في الجدول |
|---|---|---|
| `backend/Dockerfile` | بناء الـAPI (multi-stage + user عادي + healthcheck) | Dockerfile (3 نقاط) |
| `frontend/Dockerfile` | build ثم Nginx خفيف (multi-stage) | Dockerfile |
| `redis/Dockerfile` + `redis.conf` | Redis بإعدادات متاعنا + persistance | Dockerfile |
| `docker-compose.yml` | يشغّل الـ3 مع بعضهم + volume + شبكتين | Compose (3 نقاط) |
| `k8s/*.yaml` | Namespace, Secret, StatefulSet, Deployments, Services, HPA, NetworkPolicy | Orchestrateur (5 نقاط) |
| `scripts/*.sh` | أوتوماتيك: deploy، scale، test persistance | Reproductibilité |
| `RAPPORT.docx` | التقرير | Rapport (3 نقاط) |

---

## 6. الخطوات: شنوا تكتب وبالترتيب

### المرحلة 0: التحضير (Windows)
1. نصّب **Docker Desktop** وشغّلو (لازم يكون مفتوح).
2. في PowerShell:
```powershell
winget install Kubernetes.minikube
winget install Kubernetes.kubectl
```
(يطوّل شوية، صبر. سكّر وافتح PowerShell بعد التنصيب.)
3. فك الضغط على `projet-conteneurs.zip` وادخل للدوسي:
```powershell
cd projet-conteneurs
```

### المرحلة 1: Docker Compose (تخدم بدون Minikube)
```powershell
cp .env.example .env
docker compose up -d --build
docker compose ps
```
افتح المتصفح على **http://localhost:8080**. لازم تشوف الصفحة والعدّاد.

**شنوا يصير وراء الكواليس؟**
- Docker يبني 3 images من الـ3 Dockerfiles.
- يشغّل redis الأول، وكي يولّي "healthy" يشغّل backend، وبعدها frontend.
- `redis-data` هو الـvolume: المعلومات تبقى.

**اختبار الـvolume (هذا يعجب الأستاذ):**
```powershell
# ابعث رسالة من الصفحة، بعدها:
docker compose down
docker compose up -d
```
افتح الصفحة: الرسالة والعدّاد باقيين ✅ (ما صفّرش العدّاد).

**scalabilité في Compose:**
```powershell
docker compose up -d --scale backend=3
docker compose restart frontend
docker compose ps
```

**قيس حجم الـimages للتقرير:**
```powershell
docker images
```
(صوّر الشاشة.)

### المرحلة 2: Kubernetes (Minikube)
خيار سهل: Git Bash أو WSL ويخدم `./scripts/deploy-k8s.sh` مباشرة. وإلا في PowerShell:

```powershell
minikube start --driver=docker --cpus=2 --memory=3072 --cni=calico
minikube addons enable metrics-server

# نبنيو الـimages في Docker متاع Minikube
& minikube -p minikube docker-env --shell powershell | Invoke-Expression
docker build -t microservices-redis:1.0 ./redis
docker build -t microservices-backend:1.0 ./backend
docker build -t microservices-frontend:1.0 --build-arg BUILD_VERSION=1.0.0 ./frontend

# ننشرو
kubectl apply -f k8s/00-namespace.yaml
kubectl apply -f k8s/01-config.yaml
kubectl apply -f k8s/02-redis.yaml
kubectl -n microservices rollout status statefulset/redis
kubectl apply -f k8s/03-backend.yaml -f k8s/04-frontend.yaml -f k8s/05-hpa.yaml -f k8s/06-networkpolicy.yaml
kubectl -n microservices get pods,svc,pvc,hpa

# نفتحو التطبيق
minikube service frontend -n microservices
```
⚠️ **نقطة مهمة:** نفذ سطر `docker-env` في **نفس** نافذة PowerShell اللي تبني فيها الـimages، وإلا Kubernetes ما يلقاش الـimages (يعطيك `ErrImageNeverPull` أو `ImagePullBackOff`).

**اختبار الـscalabilité (الجزء الأهم):**
```powershell
kubectl -n microservices get pods -l app=backend
kubectl -n microservices scale deployment/backend --replicas=5
kubectl -n microservices get pods -l app=backend
```
من الصفحة اضغط "Interroger l'API ×10": تشوف 5 أسماء Pods مختلفة. بعدها ارجع لـ2:
```powershell
kubectl -n microservices scale deployment/backend --replicas=2
```

**اختبار الـpersistance:**
```powershell
# ابعث رسالة من الصفحة، بعدها:
kubectl -n microservices delete pod redis-0
kubectl -n microservices get pods -w
```
K8s يرجّع `redis-0` وحدو، والرسالة باقية ✅ لأن الـPVC محفوظ.

**اختبار الـautoscaling (اختياري، يبهر):** شغّل `./scripts/scale-test.sh` وشوف `kubectl -n microservices get hpa -w`.

**التنظيف:**
```powershell
kubectl delete namespace microservices
docker compose down -v
```

---

## 7. الـ"trucs" اللي يخليوك تفهم باش تجاوب في الـdémo

**علاش multi-stage؟** باش الـimage النهائية ما فيهاش أدوات الـbuild: أخف، أسرع، وأكثر أمان.

**علاش user ما هوش root؟** إذا واحد اخترق التطبيق، يكون عندو صلاحيات قليلة.

**علاش Redis في StatefulSet وماشي Deployment؟** لأنو فيه بيانات: يحتاج اسم ثابت (`redis-0`) وتخزين ثابت (PVC).

**شنوا الفرق بين readiness و liveness؟**
- *liveness*: "هل التطبيق حي؟" إذا لا، K8s يعاود يشغّلو.
- *readiness*: "هل جاهز يستقبل طلبات؟" إذا لا، K8s يوقف الطلبات عليه ما يقتلوش.
عندنا الـAPI ما تتقتلش كان Redis طاح، بل تتوقف فقط من استقبال الطلبات (هذا قرار مقصود).

**كيفاش frontend يلقى backend؟** بالاسم: `http://backend:3000`. الـDNS الداخلي (Compose أو K8s) يحوّل الاسم لعنوان IP. نفس الاسم في الحالتين، علاش الانتقال من Compose لـK8s سهل.

**علاش `internal: true` في Compose و NetworkPolicy في K8s؟** باش Redis ما يوصلو كان الـAPI (principe du moindre privilège).

**كيفاش نتفادى coupure وقت التحديث؟** `RollingUpdate` مع `maxUnavailable: 0`: نطلعو pod جديد قبل ما نطفيو القديم.

**Secret في K8s آمن؟** هو base64 ماشي تشفير حقيقي. في الإنتاج نستعملو gestionnaire خارجي (AWS Secrets Manager مثلا). قولها بصراحة، الأستاذ يحب الصدق.

**وشنوا هو AWS ECS؟** ECS هو بديل K8s من Amazon: Task Definition = Pod، Service ECS = Deployment، desiredCount = replicas. (جدول المقارنة في التقرير القسم 7.)

---

## 8. شنوا لازم تعملو إنت (ما نجمش نعملو عليك)

1. **شغّل المشروع فعلا مرة قبل الـdémo** وصوّر:
   - `docker compose ps`
   - صفحة الويب
   - `docker images` (الأحجام)
   - `kubectl get pods -o wide`
   - الـscale من 2 لـ5
   - اختبار الـpersistance
2. **عمّر التقرير**: الجدول متاع أحجام الـimages، ولصق الـcaptures.
3. **بدّل صفحة الغلاف**: الأسماء، المادة، الأستاذ. (السطر `author:` في أول `RAPPORT.md` إذا تعدّل بـpandoc، أو عدّلو مباشرة في Word.)
4. **الـschéma** موجود في `docs/architecture.png` وداخل التقرير، ما تحتاج تعملو.
5. **كرّر الـdémo** مرتين على الأقل (التمرين يساوي 3 نقاط).

---

## 9. الـdémo خطوة بخطوة (8 دقايق)

1. "هذا تطبيق 3 tiers" وورّي schéma.
2. `docker compose up -d --build` ثم `docker compose ps`.
3. افتح الصفحة، ابعث رسالة.
4. `docker compose down` ثم `up`: الرسالة باقية (volume).
5. في Minikube: `kubectl get pods,svc,pvc -n microservices`.
6. زر ×10، ثم `kubectl scale ... --replicas=5`، ثم زر ×10 مرة أخرى.
7. `kubectl delete pod redis-0`: البيانات باقية.
8. اختم بـ"احنا مررنا من VM ثقيلة لـconteneurs خفيفة وقابلة للتوسع".

---

## 10. مشاكل متوقعة وحلولها السريعة

| المشكلة | الحل |
|---|---|
| `... n'est pas reconnu` | التنصيب ما كمّلش أو لازم تسكّر وتفتح PowerShell |
| Docker ما يخدمش | Docker Desktop مش مفتوح |
| `port is already allocated` | بدّل `FRONTEND_PORT` في `.env` (مثلا 8081) |
| `ErrImageNeverPull` / `ImagePullBackOff` | نسيت `docker-env` قبل الـbuild؛ عاودهم |
| HPA يعرض `<unknown>` | `minikube addons enable metrics-server` وصبر دقيقة |
| الصفحة تعطي 502 | الـbackend باش يبدا: `kubectl -n microservices logs deploy/backend` |
| `minikube start` يطوّل أو يطيح | زيد RAM لـ Docker Desktop (4 Go على الأقل) |

الله ينجحك 🍀 وإذا يخرجلك error، ابعثلي الرسالة كما هي ونصلحوها.
