'use strict';
// Étape de "build" du front : copie src/ -> dist/ en injectant la version de build.
// Sert de démonstration à la construction multi-stage (Node uniquement au build,
// l'image finale ne contient que Nginx + fichiers statiques).
const fs = require('fs');
const path = require('path');

const SRC = path.join(__dirname, 'src');
const DIST = path.join(__dirname, 'dist');
const version = process.env.BUILD_VERSION || new Date().toISOString().slice(0, 10);

fs.rmSync(DIST, { recursive: true, force: true });
fs.mkdirSync(DIST, { recursive: true });

for (const file of fs.readdirSync(SRC)) {
  let content = fs.readFileSync(path.join(SRC, file), 'utf8');
  if (file.endsWith('.html')) content = content.replace(/__BUILD_VERSION__/g, version);
  if (file.endsWith('.css') || file.endsWith('.js')) {
    // minification légère : suppression des commentaires de ligne complets et lignes vides
    content = content.split('\n').filter((l) => l.trim() && !l.trim().startsWith('//')).join('\n');
  }
  fs.writeFileSync(path.join(DIST, file), content);
}
console.log(`Build front OK (version ${version}) -> ${DIST}`);
