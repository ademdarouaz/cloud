'use strict';

const $ = (id) => document.getElementById(id);

async function api(path, options) {
  const res = await fetch(`/api${path}`, options);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function loadVisits() {
  try {
    const data = await api('/visits');
    $('visits').textContent = data.visits;
    $('served-by').textContent = data.served_by;
  } catch (e) {
    $('visits').textContent = 'indisponible';
    $('served-by').textContent = e.message;
  }
}

async function pingMany() {
  const list = $('pods');
  list.innerHTML = '';
  const counts = {};
  for (let i = 0; i < 10; i++) {
    try {
      const { hostname } = await api('/info');
      counts[hostname] = (counts[hostname] || 0) + 1;
    } catch { counts['erreur'] = (counts['erreur'] || 0) + 1; }
  }
  Object.entries(counts).forEach(([pod, n]) => {
    const li = document.createElement('li');
    li.textContent = `${pod} : ${n} requête(s)`;
    list.appendChild(li);
  });
}

async function loadMessages() {
  try {
    const { messages } = await api('/messages');
    const ul = $('messages');
    ul.innerHTML = '';
    messages.forEach((m) => {
      const li = document.createElement('li');
      // textContent (et non innerHTML) : protège contre les injections XSS
      const strong = document.createElement('strong');
      strong.textContent = m.author;
      const span = document.createElement('span');
      span.textContent = ` — ${m.text}`;
      const small = document.createElement('small');
      small.textContent = ` (${new Date(m.at).toLocaleString('fr-FR')} · ${m.pod})`;
      li.append(strong, span, small);
      ul.appendChild(li);
    });
  } catch { /* API indisponible : on garde l'affichage actuel */ }
}

$('refresh').addEventListener('click', loadVisits);
$('ping').addEventListener('click', pingMany);
$('form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  try {
    await api('/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ author: $('author').value, text: $('text').value }),
    });
    $('text').value = '';
    loadMessages();
  } catch (e) { alert(`Envoi impossible : ${e.message}`); }
});

loadVisits();
loadMessages();
