#!/usr/bin/env bash
# Prouve la persistance des données : on détruit le pod Redis, les données doivent survivre.
set -euo pipefail

NS=microservices
URL="$(minikube service frontend -n $NS --url | head -n1)"

echo ">> Ajout d'un message et lecture du compteur"
curl -s -X POST "$URL/api/messages" -H 'Content-Type: application/json' \
  -d '{"author":"test","text":"message avant suppression du pod"}'; echo
BEFORE=$(curl -s "$URL/api/visits"); echo "avant : $BEFORE"

echo ">> Suppression du pod redis-0 (le StatefulSet le recrée, le PVC est conservé)"
kubectl -n $NS delete pod redis-0
kubectl -n $NS wait --for=condition=ready pod/redis-0 --timeout=120s
sleep 5

echo ">> Relecture"
AFTER=$(curl -s "$URL/api/visits"); echo "après : $AFTER"
curl -s "$URL/api/messages" | head -c 400; echo
echo "Le compteur a continué (et non repris à 1) : les données sont persistantes."
kubectl -n $NS get pvc
