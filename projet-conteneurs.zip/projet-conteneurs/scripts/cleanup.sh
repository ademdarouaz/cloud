#!/usr/bin/env bash
# Nettoyage. Utilisation : ./scripts/cleanup.sh [compose|k8s|all]
set -euo pipefail
cd "$(dirname "$0")/.."

case "${1:-all}" in
  compose) docker compose down -v ;;
  k8s)     kubectl delete namespace microservices --ignore-not-found ;;
  all)     docker compose down -v || true
           kubectl delete namespace microservices --ignore-not-found || true ;;
  *) echo "usage: $0 [compose|k8s|all]"; exit 1 ;;
esac
