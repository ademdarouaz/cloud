#!/usr/bin/env bash
# Démonstration de la scalabilité : redimensionnement manuel puis vérification
# de la répartition de charge entre réplicas.
set -euo pipefail

NS=microservices
URL="$(minikube service frontend -n $NS --url | head -n1)"
echo "URL de l'application : $URL"

distribution() {
  echo ">> 30 requêtes vers /api/info -> répartition par pod :"
  for _ in $(seq 1 30); do curl -s "$URL/api/info"; echo; done \
    | sed -E 's/.*"hostname":"([^"]+)".*/\1/' | sort | uniq -c
}

echo "=== 1. État initial ==="
kubectl -n $NS get deploy backend
distribution

echo; echo "=== 2. Passage à 5 réplicas ==="
kubectl -n $NS scale deployment/backend --replicas=5
kubectl -n $NS rollout status deployment/backend
kubectl -n $NS get pods -l app=backend
distribution

echo; echo "=== 3. Retour à 2 réplicas ==="
kubectl -n $NS scale deployment/backend --replicas=2
kubectl -n $NS rollout status deployment/backend
kubectl -n $NS get pods -l app=backend

echo; echo "=== 4. Test d'autoscaling (HPA) : charge CPU pendant 90 s ==="
echo "Dans un 2e terminal :  kubectl -n $NS get hpa backend -w"
END=$((SECONDS + 90))
while [ $SECONDS -lt $END ]; do
  for _ in $(seq 1 8); do curl -s "$URL/api/load?ms=500" >/dev/null & done
  wait
done
kubectl -n $NS get hpa backend
kubectl -n $NS get pods -l app=backend
