#!/usr/bin/env bash
# Déploiement complet sur Minikube : build des images + application des manifestes.
set -euo pipefail
cd "$(dirname "$0")/.."

NS=microservices
VERSION="${BUILD_VERSION:-1.0.0}"

command -v minikube >/dev/null || { echo "minikube introuvable"; exit 1; }
command -v kubectl  >/dev/null || { echo "kubectl introuvable";  exit 1; }

if ! minikube status >/dev/null 2>&1; then
  echo ">> Démarrage de Minikube (CNI Calico pour appliquer les NetworkPolicy)"
  minikube start --cpus=2 --memory=3072 --cni=calico
fi

echo ">> Activation de metrics-server (nécessaire à l'HPA)"
minikube addons enable metrics-server >/dev/null

echo ">> Build des images directement dans le Docker de Minikube"
eval "$(minikube docker-env)"
docker build -t microservices-redis:1.0    ./redis
docker build -t microservices-backend:1.0  ./backend
docker build -t microservices-frontend:1.0 --build-arg BUILD_VERSION="$VERSION" ./frontend

echo ">> Application des manifestes"
kubectl apply -f k8s/00-namespace.yaml
kubectl apply -f k8s/01-config.yaml
kubectl apply -f k8s/02-redis.yaml
kubectl -n $NS rollout status statefulset/redis --timeout=120s
kubectl apply -f k8s/03-backend.yaml -f k8s/04-frontend.yaml -f k8s/05-hpa.yaml -f k8s/06-networkpolicy.yaml
kubectl -n $NS rollout status deployment/backend  --timeout=120s
kubectl -n $NS rollout status deployment/frontend --timeout=120s

echo ">> État du cluster"
kubectl -n $NS get pods,svc,pvc,hpa -o wide
echo
echo "Application : exécuter  ->  minikube service frontend -n $NS --url"
