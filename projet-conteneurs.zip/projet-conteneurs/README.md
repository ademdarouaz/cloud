# Conteneurisation et Orchestration : Docker, Compose, Kubernetes (Minikube)

Application micro-services en 3 tiers : **Nginx** (front) → **Node.js/Express** (API) → **Redis** (base persistante).

```
projet-conteneurs/
├── backend/            API Node.js + Dockerfile multi-stage
├── frontend/           Site statique + Dockerfile multi-stage (build Node → Nginx)
├── redis/              Dockerfile + redis.conf (persistance AOF)
├── docs/               Schéma d'architecture
├── SHARH_TN.md         Explication complète en arabe tunisien
├── docker-compose.yml  Orchestration locale
├── .env.example        Variables (mot de passe Redis, port)
├── k8s/                Manifestes Kubernetes (Namespace, Config, StatefulSet, Deployments, Services, HPA, NetworkPolicy)
├── scripts/            deploy-k8s.sh · scale-test.sh · test-persistance.sh · cleanup.sh
└── RAPPORT.md          Rapport technique complet
```

## Prérequis
Docker ≥ 24 (avec Compose v2), pour la partie 2 : Minikube ≥ 1.32 et kubectl.

## Partie 1 : Docker Compose (local)
```bash
cp .env.example .env
docker compose up -d --build
docker compose ps                 # les 3 services doivent être "healthy"/"running"
# Ouvrir http://localhost:8080
docker compose up -d --scale backend=3   # scalabilité locale
docker compose down               # arrêt (données conservées) ; ajouter -v pour effacer le volume
```

## Partie 2 : Kubernetes (Minikube)
```bash
./scripts/deploy-k8s.sh                   # démarre Minikube, construit les images, applique les manifestes
minikube service frontend -n microservices --url   # URL de l'application
./scripts/scale-test.sh                   # redimensionnement 2 → 5 → 2 réplicas + autoscaling HPA
./scripts/test-persistance.sh             # suppression du pod Redis, données conservées
./scripts/cleanup.sh k8s                  # nettoyage
```

Commandes manuelles équivalentes :
```bash
kubectl scale deployment/backend -n microservices --replicas=5
kubectl get pods -n microservices -o wide
kubectl logs -n microservices deploy/backend
```

## Dépannage rapide
| Symptôme | Cause probable | Solution |
|---|---|---|
| `ErrImageNeverPull` / `ImagePullBackOff` | Image construite hors du Docker de Minikube | `eval $(minikube docker-env)` puis rebuild |
| HPA affiche `<unknown>` | metrics-server absent | `minikube addons enable metrics-server`, attendre 1 min |
| Pod backend `0/1 Ready` | Redis pas prêt (readiness volontaire) | `kubectl -n microservices get pods`, voir les logs de redis-0 |
| Page vide / 502 | Backend non démarré | `kubectl -n microservices logs deploy/backend` |
