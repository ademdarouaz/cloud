---
title: "Conteneurisation et orchestration d'une application micro-services : Docker, Compose et Kubernetes"
subtitle: "Rapport technique — Proposition 2"
author: "[Noms et prénoms des étudiants] — [Module / Filière] — [Encadrant(e)]"
date: "Année universitaire 2026-2027"
lang: fr
---

# 1. Introduction et objectifs

Ce projet illustre le passage de la virtualisation lourde (machines virtuelles) à la conteneurisation légère. Une application en trois composants est conteneurisée, exécutée localement avec Docker Compose, puis déployée et mise à l'échelle sur un orchestrateur (Kubernetes via Minikube).

| Composant | Technologie | Rôle |
|---|---|---|
| Front-end | Nginx (image `nginx-unprivileged`) | Sert le site statique et joue le rôle de reverse proxy vers l'API |
| API back-end | Node.js 20 / Express | Compteur de visites, livre d'or, informations sur le pod, sondes de santé |
| Base de données | Redis 7 (image personnalisée, persistance AOF) | Stockage clé/valeur persistant |

**Conteneurs vs machines virtuelles.** Une VM embarque un système d'exploitation complet avec son noyau (plusieurs Go, démarrage en minutes). Un conteneur partage le noyau de l'hôte et n'isole que le processus et son système de fichiers (quelques dizaines de Mo, démarrage en secondes). Cela permet une densité bien supérieure, une reproductibilité totale de l'environnement et une mise à l'échelle rapide.

# 2. Architecture

![Architecture de l'application](docs/architecture.png)

- **Compose** : deux réseaux. `frontend-net` relie front et API. `backend-net` est déclaré `internal: true` : Redis n'a aucun accès à Internet et n'est joignable que par l'API.
- **Kubernetes** : un Namespace `microservices` ; Redis dans un StatefulSet avec volume persistant ; API et front dans des Deployments ; Services `ClusterIP` (API), headless (Redis) et `NodePort` (front) ; HPA et NetworkPolicy.
- La résolution de noms repose sur le DNS interne : le front appelle `http://backend:3000` et l'API appelle `redis:6379`, **à l'identique** dans Compose et dans Kubernetes, ce qui rend la migration transparente.

# 3. Partie 1 : conteneurisation (Dockerfile)

## 3.1 Dockerfile du back-end (`backend/Dockerfile`)
- **Multi-stage** : l'étape `deps` installe uniquement les dépendances de production (`npm ci --omit=dev`, installation reproductible depuis `package-lock.json`) ; l'étape `runtime` ne copie que `node_modules` et le code.
- **Image légère** : base `node:20-alpine`, cache npm nettoyé, `.dockerignore` pour exclure `node_modules`, `.git`, `.env`.
- **Sécurité** : exécution sous l'utilisateur non-root `node`, aucun paquet inutile.
- **Fiabilité** : `tini` comme processus d'init (relais correct de `SIGTERM`), `HEALTHCHECK` intégré, arrêt propre de l'API sur `SIGTERM`.
- **Cache de couches** : `package*.json` copiés avant le code, de sorte qu'une modification du code ne réinstalle pas les dépendances.

## 3.2 Dockerfile du front-end (`frontend/Dockerfile`)
- **Multi-stage** : Node n'existe que pendant le build (injection de la version, minification légère) ; l'image finale est **Nginx seul** avec les fichiers statiques. Aucun outil de build ne subsiste en production.
- Image `nginx-unprivileged` : processus non-root, écoute sur le port 8080 (> 1024).
- Configuration Nginx dédiée : reverse proxy `/api/` → `backend:3000`, point de santé `/healthz`, en-têtes de sécurité.

## 3.3 Dockerfile de Redis (`redis/Dockerfile`)
Image dérivée de `redis:7.4-alpine` qui embarque un `redis.conf` dédié : persistance AOF (`appendonly yes`, `appendfsync everysec`) dans `/data`, limite mémoire à 128 Mo avec `noeviction` (Redis refuse d'écrire plutôt que de supprimer des données), journaux vers la sortie standard. Le mot de passe n'est **jamais écrit dans l'image** : il est fourni à l'exécution par `--requirepass` (variable `.env` dans Compose, Secret dans Kubernetes). Un `HEALTHCHECK` vérifie la réponse `PONG`.

## 3.4 Taille des images (à compléter après le build)

Commande : `docker images | grep microservices`

| Image | Taille mesurée |
|---|---|
| microservices-backend:1.0 | _à remplir_ |
| microservices-frontend:1.0 | _à remplir_ |
| microservices-redis:1.0 | _à remplir_ |

À titre de comparaison, une machine virtuelle Linux minimale occupe plusieurs Go.

# 4. Partie 1 : orchestration locale (`docker-compose.yml`)

- Ordre de démarrage fiable : `depends_on` avec `condition: service_healthy`, l'API attend que Redis réponde à `redis-cli ping`.
- Secrets et paramètres externalisés dans `.env` (modèle fourni : `.env.example`, `.env` ignoré par git).
- Durcissement : `read_only`, `cap_drop: ALL`, `no-new-privileges`.
- **Volume nommé** `redis-data` : les données survivent à `docker compose down` (et ne sont supprimées qu'avec `-v`).
- Scalabilité locale : le service `backend` n'a ni port publié ni `container_name`, donc `docker compose up -d --scale backend=3` fonctionne. Nginx résolvant le nom à son démarrage, il faut le redémarrer (`docker compose restart frontend`) pour qu'il prenne en compte de nouveaux réplicas ; Kubernetes résout ce problème avec les Services.

# 5. Partie 2 : déploiement sur Kubernetes (Minikube)

| Fichier | Contenu | Points clés |
|---|---|---|
| `00-namespace.yaml` | Namespace | Isolation logique |
| `01-config.yaml` | ConfigMap + Secret | Configuration séparée de l'image ; mot de passe Redis dans un Secret |
| `02-redis.yaml` | Service headless + StatefulSet | `volumeClaimTemplates` 1 Gi, identité stable `redis-0`, `fsGroup` pour les droits du volume |
| `03-backend.yaml` | Deployment (2 réplicas) + Service ClusterIP | Sondes startup/readiness/liveness, requests/limits, RollingUpdate sans indisponibilité, utilisateur non-root, FS en lecture seule |
| `04-frontend.yaml` | Deployment (2 réplicas) + Service NodePort | Point d'entrée externe (port 30080) |
| `05-hpa.yaml` | HorizontalPodAutoscaler | 2 à 6 réplicas, cible 50 % CPU |
| `06-networkpolicy.yaml` | 2 NetworkPolicy | Redis accessible uniquement depuis l'API ; API uniquement depuis le front |
| `extras/pod-debug.yaml` | Pod isolé | Test réseau et démonstration de l'isolation |

**Choix de conception**
- *StatefulSet pour Redis* : il possède un état, il lui faut une identité et un stockage stables. Un Deployment avec plusieurs réplicas corromprait la logique de persistance.
- *Readiness vs liveness* : la sonde de vivacité (`/api/healthz`) ne dépend pas de Redis, pour éviter une boucle de redémarrages si la base est temporairement absente ; la sonde de disponibilité (`/api/readyz`) vérifie Redis, ce qui retire du Service un pod qui ne peut pas répondre.
- *Images locales* : elles sont construites dans le démon Docker de Minikube (`eval $(minikube docker-env)`) avec `imagePullPolicy: IfNotPresent`, sans registre externe.

## 5.1 Test de scalabilité
`scripts/scale-test.sh` enchaîne :

1. état initial (2 réplicas) et mesure de la répartition de 30 requêtes par pod ;
2. `kubectl scale deployment/backend --replicas=5` : de nouveaux pods apparaissent, la répartition s'étale sur 5 noms de pods ;
3. retour à 2 réplicas ;
4. génération de charge CPU sur `/api/load` : le HPA augmente automatiquement le nombre de réplicas (observable avec `kubectl get hpa -w`).

Le Service Kubernetes répartit les connexions entre les pods prêts ; le champ `served_by`/`hostname` renvoyé par l'API rend ce load-balancing visible dans l'interface (bouton « Interroger l'API ×10 »).

# 6. Volumes, données persistantes et réseau

| Environnement | Persistance | Réseau |
|---|---|---|
| Compose | Volume nommé `redis-data` monté sur `/data` | `frontend-net` + `backend-net` (interne) ; DNS par nom de service |
| Kubernetes | PVC `data-redis-0` (StatefulSet) | Services + DNS du cluster ; NetworkPolicy |

**Test de persistance** (`scripts/test-persistance.sh`) : écriture de données, suppression du pod `redis-0`, recréation automatique par le StatefulSet, puis relecture. Le compteur de visites continue sa valeur (il ne repart pas à 1) : preuve que les données résident sur le volume et non dans le conteneur.

# 7. Alternative : déploiement sur AWS ECS (Fargate)

Si AWS Academy est utilisé à la place de Minikube, la correspondance est la suivante :

| Kubernetes | AWS ECS |
|---|---|
| Deployment / replicas | Service ECS / `desiredCount` |
| Pod (conteneurs) | Task Definition (conteneurs `frontend`, `backend`) |
| Service / DNS interne | Service Connect ou Cloud Map ; ALB pour l'entrée |
| Secret | AWS Secrets Manager / SSM |
| PVC | Volume EFS (ou ElastiCache Redis pour une base managée) |
| HPA | Application Auto Scaling |

Étapes : pousser les images sur ECR, créer la Task Definition (CPU/mémoire, variables d'environnement, ports), créer un Service ECS derrière un Application Load Balancer, puis modifier `desiredCount` pour tester la scalabilité. Dans ce projet, la voie Kubernetes/Minikube a été retenue car elle est gratuite, reproductible hors ligne et couvre aussi les notions de Pods, Services et Deployments citées dans l'énoncé.

# 8. Reproductibilité

Les commandes complètes sont dans `README.md`. Résumé :

```bash
cp .env.example .env && docker compose up -d --build     # Partie 1
./scripts/deploy-k8s.sh                                  # Partie 2
./scripts/scale-test.sh && ./scripts/test-persistance.sh
```

Versions utilisées : Node 20, Nginx 1.27, Redis 7.4, Docker Compose v2, Kubernetes (Minikube) avec Calico et metrics-server.

**Vérifications effectuées lors de la rédaction** : l'API a été exécutée contre un vrai serveur Redis (sondes, compteur, livre d'or, validation des entrées, arrêt propre sur SIGTERM) ; le build du front a été exécuté ; `docker compose config` valide le fichier Compose ; les manifestes Kubernetes ont été validés syntaxiquement. La construction des images et le déploiement sur Minikube doivent être exécutés sur la machine de l'étudiant (aucun démon Docker n'était disponible dans l'environnement de rédaction). Il est recommandé d'y joindre vos propres captures d'écran (`docker compose ps`, `kubectl get pods`, interface web, résultat du scale).

# 9. Difficultés rencontrées et améliorations possibles

- **Ordre de démarrage** Redis/API : résolu par les healthchecks Compose et les sondes de disponibilité Kubernetes, ainsi que par la stratégie de reconnexion automatique du client Redis.
- **Droits sur le volume** : l'utilisateur non-root de Redis ne pouvait pas écrire sur le PVC sans `fsGroup`.
- **Découverte de réplicas par Nginx** (Compose) : limite du DNS statique, résolue côté Kubernetes par les Services.
- Améliorations : Ingress avec TLS, Redis en haute disponibilité (Sentinel/cluster), CI/CD avec scan d'images (Trivy), Helm/Kustomize pour les environnements, registre privé (ECR/GHCR).

# 10. Grille de notation : correspondance

| Critère | Points | Éléments du livrable |
|---|---|---|
| Qualité des Dockerfile | 3 | 3 Dockerfile (back, front, Redis) : multi-stage (back et front), Alpine, non-root, tini, HEALTHCHECK, `.dockerignore`, cache de couches |
| Composition locale | 3 | `docker-compose.yml` : healthchecks, `depends_on`, `.env`, réseaux, durcissement, `--scale` |
| Déploiement orchestrateur | 5 | 7 manifestes K8s, StatefulSet/Deployments/Services, sondes, ressources, HPA, rolling update, scale 2→5→2 |
| Volumes et réseau | 3 | Volume nommé / PVC, réseau interne, NetworkPolicy, DNS de service, test de persistance |
| Rapport et reproductibilité | 3 | Ce rapport, `README.md`, scripts automatisés, versions fixées |
| Démo live | 3 | Voir la trame de démonstration ci-dessous |

# 11. Trame de démonstration (≈ 8 min) et questions probables

**Déroulé**
1. `docker compose up -d --build`, `docker compose ps`, ouvrir `localhost:8080`, ajouter un message.
2. `docker compose down` puis `up` : les données sont toujours là (volume).
3. `./scripts/deploy-k8s.sh`, `kubectl get pods,svc,pvc -n microservices`.
4. Dans l'interface, « Interroger l'API ×10 » ; `kubectl scale ... --replicas=5` ; relancer : 5 pods apparaissent dans la répartition.
5. `kubectl delete pod redis-0` : les données persistent.

**Questions fréquentes et réponses**
- *Pourquoi multi-stage ?* L'image finale ne contient pas les outils de build : plus petite, surface d'attaque réduite, démarrage plus rapide.
- *Différence entre image et conteneur ?* L'image est un modèle immuable en lecture seule ; le conteneur en est une instance en cours d'exécution avec une couche inscriptible.
- *Pourquoi un StatefulSet pour Redis ?* Identité réseau et stockage stables par pod ; un Deployment n'offre pas cela.
- *Différence Pod / Deployment / Service ?* Le Pod est l'unité d'exécution ; le Deployment maintient le nombre souhaité de Pods et gère les mises à jour ; le Service donne une adresse DNS stable et répartit la charge.
- *Que se passe-t-il si un pod backend meurt ?* Le Deployment en recrée un ; pendant ce temps, la sonde de disponibilité le retire du Service, sans perte de service grâce aux autres réplicas.
- *Readiness vs liveness ?* Readiness : peut-il recevoir du trafic ? Liveness : faut-il le redémarrer ?
- *Où sont stockés les secrets ?* Secret Kubernetes (encodé en base64, non chiffré par défaut) : en production, on utiliserait un gestionnaire externe.
- *Comment mettre à jour sans coupure ?* `RollingUpdate` avec `maxUnavailable: 0`, plus sondes de disponibilité.
- *Pourquoi Redis n'est-il pas exposé ?* Principe du moindre privilège : réseau interne (Compose) et NetworkPolicy (Kubernetes).
