'use strict';

const os = require('os');
const express = require('express');
const { createClient } = require('redis');

const PORT = parseInt(process.env.PORT || '3000', 10);
const REDIS_HOST = process.env.REDIS_HOST || 'redis';
const REDIS_PORT = process.env.REDIS_PORT || '6379';
const REDIS_PASSWORD = process.env.REDIS_PASSWORD || undefined;
const MAX_MESSAGES = 50;

const app = express();
app.use(express.json({ limit: '10kb' }));

const redis = createClient({
  socket: {
    host: REDIS_HOST,
    port: parseInt(REDIS_PORT, 10),
    // Reconnexion automatique : indispensable car Redis peut démarrer après l'API
    reconnectStrategy: (retries) => Math.min(retries * 200, 3000),
  },
  password: REDIS_PASSWORD,
});

redis.on('error', (err) => console.error('[redis] erreur :', err.message));
redis.on('ready', () => console.log(`[redis] connecté à ${REDIS_HOST}:${REDIS_PORT}`));

// --- Sondes de santé -------------------------------------------------------
// Liveness : le processus répond (ne dépend PAS de Redis, pour éviter un
// redémarrage en boucle si Redis est momentanément indisponible).
app.get('/api/healthz', (_req, res) => res.json({ status: 'ok' }));

// Readiness : l'API est prête uniquement si Redis répond.
app.get('/api/readyz', async (_req, res) => {
  try {
    await redis.ping();
    res.json({ status: 'ready' });
  } catch {
    res.status(503).json({ status: 'redis indisponible' });
  }
});

// --- API métier ------------------------------------------------------------
// Infos sur le pod/conteneur qui répond : permet de visualiser le
// load-balancing entre réplicas pendant la démo de scalabilité.
app.get('/api/info', (_req, res) => {
  res.json({ hostname: os.hostname(), pid: process.pid, uptime_s: Math.round(process.uptime()) });
});

// Compteur de visites persistant (clé Redis "visits").
app.get('/api/visits', async (_req, res) => {
  try {
    const visits = await redis.incr('visits');
    res.json({ visits, served_by: os.hostname() });
  } catch (err) {
    res.status(503).json({ error: 'base de données indisponible' });
  }
});

// Livre d'or : liste Redis, les plus récents en tête.
app.get('/api/messages', async (_req, res) => {
  try {
    const raw = await redis.lRange('messages', 0, MAX_MESSAGES - 1);
    res.json({ messages: raw.map((m) => JSON.parse(m)), served_by: os.hostname() });
  } catch {
    res.status(503).json({ error: 'base de données indisponible' });
  }
});

app.post('/api/messages', async (req, res) => {
  const author = String(req.body?.author || '').trim().slice(0, 40);
  const text = String(req.body?.text || '').trim().slice(0, 280);
  if (!author || !text) {
    return res.status(400).json({ error: 'author et text sont obligatoires' });
  }
  try {
    const entry = { author, text, at: new Date().toISOString(), pod: os.hostname() };
    await redis.lPush('messages', JSON.stringify(entry));
    await redis.lTrim('messages', 0, MAX_MESSAGES - 1);
    res.status(201).json(entry);
  } catch {
    res.status(503).json({ error: 'base de données indisponible' });
  }
});

// Route de charge CPU volontaire : sert à déclencher l'autoscaling (HPA).
app.get('/api/load', (req, res) => {
  const ms = Math.min(parseInt(req.query.ms || '200', 10) || 200, 2000);
  const end = Date.now() + ms;
  let x = 0;
  while (Date.now() < end) x += Math.sqrt(Math.random());
  res.json({ burned_ms: ms, served_by: os.hostname() });
});

// --- Démarrage & arrêt propre ---------------------------------------------
let server;
(async () => {
  redis.connect().catch((e) => console.error('[redis] connexion initiale :', e.message));
  server = app.listen(PORT, '0.0.0.0', () => console.log(`[api] écoute sur :${PORT}`));
})();

// Kubernetes / Docker envoient SIGTERM : on termine proprement les requêtes en cours.
function shutdown(signal) {
  console.log(`[api] ${signal} reçu, arrêt propre...`);
  server?.close(async () => {
    try { await redis.quit(); } catch { /* ignore */ }
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 8000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
